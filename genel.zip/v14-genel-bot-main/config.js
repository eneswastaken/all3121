module.exports = {
    token: "",
    prefix: "!"
}

